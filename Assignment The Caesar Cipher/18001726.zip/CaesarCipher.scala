object CaesarCipher extends App{

	val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    val n =scala.io.StdIn.readLine("Encrypt or Decrypt By: ")//User input for the index of shifting.
	val index = (n.toInt + alphabet.size) % alphabet.size 

	val message = scala.io.StdIn.readLine("Message to be encrypt or decrypt: ")//User input for the message that to be encrypt or decrypt
    //Same function for encyption and decryption. If index is positive process is encryption else it is decryption
	val outputmessage = message.map( (a: Char) => 
    { 
       val x = alphabet.indexOf(a.toUpper)
		if (x == -1){ //If the character not found on alphabet return to our message.
			a
		}
		else{ //If character found perform the shifting of the character.
			alphabet((x + index) % alphabet.size)
			} 
	});
	println(outputmessage);
}
