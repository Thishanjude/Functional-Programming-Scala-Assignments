object vol{
  
   def main(args: Array[String])
   {
       def volume (r:Float)=(4.0/3.0)*(22.0/7.0)*r*r*r
       println("Volume of Sphere is" +volume(5)+ " cubic units")
   }
}