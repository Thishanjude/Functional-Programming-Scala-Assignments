object price{
  
   def main(args: Array[String])
   {
       var x : Double = 24.95
       var d : Double= x*0.4
       var p : Double= (x-d)*60+(3*50)+(10*0.75)
       println("Total price is " +p+ " rupees")
   }
}