object convert{
  
   def main(args: Array[String])
   {
       def con(c:Double)=(c*1.8)+32
       println("Temperature in Fahrenheit is  " +con(35)+ " F")
   }
}