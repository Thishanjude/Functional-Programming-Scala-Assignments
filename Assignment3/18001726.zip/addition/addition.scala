object addition{
  
   def main(args: Array[String])
   {
       def sum(n:Int):Int=
       {
           if(n==1) 1
           else n+sum(n-1)
       }
       println("sum of numbers from 0 to 10 is "+sum(10))
       println("sum of numbers from 0 to 15 is "+sum(15))
   }
}