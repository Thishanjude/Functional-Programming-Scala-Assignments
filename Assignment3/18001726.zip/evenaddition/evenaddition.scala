object evenaddition{
  
   def main(args: Array[String])
   {
       def sum(a:Int,n:Int):Int=
       {
         if(a>n)  0
         else a+sum(a+2,n)
         
       }
       println("Sum of even numbers from 0 to 17 is  "+sum(0,17))
       println("Sum of even numbers from 0 to 8 is "+sum(0,8))
   }
}