object OddorEven{
  
   def main(args: Array[String])
   {
       def even(n:Int):Boolean=n match
       {
           case 0=>true
           case _=>odd(n-1)
       }
       def odd(n:Int):Boolean=n match
       {
           case 0=>false
           case _=>even(n-1)
       }
       println(odd(3))
       println(even(10))
   }
}