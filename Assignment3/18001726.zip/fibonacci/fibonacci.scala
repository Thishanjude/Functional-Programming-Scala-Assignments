object fibonacci{
  
   def main(args: Array[String])
   {
       def fib(n:Int):Int=n match
       {
         case n if n==0 =>0
         case n if n==1=> 1
         case n => fib(n-1)+fib(n-2)
       }
       def fs(n:Int):Any= 
       {
          if(n>0) fs(n-1)
          println(fib(n))
       }
       println(fs(10))
      
   }
}