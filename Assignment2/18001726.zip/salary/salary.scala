object salary{
  
   def main(args: Array[String])
   {
       def WR (h:Int)=h*150
       def OT (h:Int)=h*75

       def Sal (h1:Int,h2:Int)=WR(h1)+OT(h2)
       def tax (h1:Int,h2:Int)=Sal(h1,h2)*0.1

       def THsalary(h1:Int,h2:Int)=Sal(h1,h2)-tax(h1,h2)
       println("Total takehome Salary is "+THsalary(40,20))
   }
}