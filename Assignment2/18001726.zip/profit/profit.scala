object profit{
  
   def main(args: Array[String])
   {
       def people (m:Int)=120+(15-m)*4
       def income (m:Int)= people(m)*m
    
       def performance(m:Int)=500+people(m)*3
       def profit(m:Int)= income(m)-performance(m)
       
       println("Total profit if ticket price is Rs.5 "+profit(15))
       println("Total profit if ticket price is Rs.10 "+profit(10))
       println("Total profit if ticket price is Rs.15 "+profit(15))
       println("Total profit if ticket price is Rs.20 "+profit(20))
       println("Total profit if ticket price is Rs.25 "+profit(25))
       println("Total profit if ticket price is Rs.30 "+profit(30))
       println("Total profit if ticket price is Rs.35 "+profit(35))
       println("Total profit if ticket price is Rs.40 "+profit(40))
       
       println("")
       println("")


       println("By comparing above values maximum profit he can get at Rs.25 per ticket")
   }
}