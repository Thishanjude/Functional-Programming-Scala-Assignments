import scala.io.StdIn.readInt
import scala.io.StdIn.readLine

object Bank{
    
    class Account(id:String,n: Int, b: Double)
    {
        val nic:String=id
        val acnumber: Int = n
        var balance: Double = b

        def withdraw(a:Double) = this.balance=this.balance-a
        def deposit(a:Double) = this.balance=this.balance+a
        def transfer(a:Account,b:Double)= {
        this.withdraw(b)
        a.deposit(b)
        }

        override def toString = "["+nic+":"+acnumber +":"+ balance+"]"
    }


    def main(args: Array[String])
    {
        var a1= new Account("11111111",10000,50000.00)
        var a2= new Account("22222222",10001,46000.00)
        var a3= new Account("33333333",10002,-2500.60)
        var a4= new Account("44444444",10003,14000.00)
        var a5= new Account("55555555",10004,86000.00)
        var a6= new Account("66666666",10005,-4000.00)

        var bank:List[Account]=List(a1,a2,a3,a4,a5,a6)
        val negative=(b:List[Account])=> b.filter(_.balance<0)
        val balance=(b:List[Account])=> b.map(_.balance).sum
      /*  val interest= 
       for(i<-0 to 5)
        {
            List[i].map(
                if(_.balance>0)
                {
                    _.balance*1.05
                }
                else
                {
                     _.balance*1.1
                }
                ).sum
        }*/
        println("\n\tList of accounts with negative balance : "+negative(bank))
        println("\n\tSum of the account balances : "+balance(bank))
        //println("\n\tFinal balances after applying interests : "+interest(bank))
        //tried to print the interest but i cant exactly write the code there are some errors.

    }
}